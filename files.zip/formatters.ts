import { format, parseISO } from 'date-fns'
import type { ModelName } from '../types'

export function formatDate(dateStr: string | undefined, fmt = 'MMM dd'): string {
  if (!dateStr) return ''
  try {
    return format(parseISO(dateStr), fmt)
  } catch {
    return dateStr
  }
}

export function formatMetric(value: number, metric: string): string {
  if (metric === 'r2' || metric === 'nse') return value.toFixed(3)
  if (metric === 'accuracy' || metric === 'f1') return `${(value * 100).toFixed(1)}%`
  return value.toFixed(2)
}

export function exportToCSV(data: Record<string, unknown>[], filename: string): void {
  if (!data.length) return
  const headers = Object.keys(data[0])
  const rows = data.map((row) =>
    headers
      .map((h) => {
        const val = row[h]
        if (typeof val === 'string' && val.includes(',')) return `"${val}"`
        return String(val ?? '')
      })
      .join(',')
  )
  const csv = [headers.join(','), ...rows].join('\n')
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${filename}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

export const MODEL_COLORS: Record<string, string> = {
  LSTM: '#0F6E56',
  GRU: '#378ADD',
  BiLSTM: '#8B5CF6',
  'CNN-LSTM': '#E24B4A',
  WLSTM: '#BA7517',
  StackedLSTM: '#3B6D11',
  SimpleRNN: '#F59E0B',
  'LSTM+Attention': '#EC4899',
  Transformer: '#06B6D4',
}

export function normalizeModelName(backendName: string): ModelName {
  const map: Record<string, ModelName> = {
    lstm: 'LSTM',
    gru: 'GRU',
    bilstm: 'BiLSTM',
    cnn_lstm: 'CNN-LSTM',
    wlstm: 'WLSTM',
    stacked_lstm: 'StackedLSTM',
    simplernn: 'SimpleRNN',
    lstm_attention: 'LSTM+Attention',
    transformer: 'Transformer',
  }
  return map[backendName.toLowerCase()] ?? (backendName as ModelName)
}

export const TANK_LEVEL_COLORS = {
  Low: '#E24B4A',
  Medium: '#BA7517',
  Full: '#3B6D11',
}

export const DECISION_COLORS: Record<string, string> = {
  Irrigate: '#3B6D11',
  'No Irrigate': '#6B7280',
  Monitor: '#BA7517',
}
