# AquaAI — Refactoring Summary

## Files Changed

### `frontend/src/utils/formatters.ts`
- `normalizeModelName` return type tightened to `ModelName` (was `string`)
- No functional changes

### `frontend/src/components/charts/IrrigationHeatmap.tsx`
- Removed unused imports: `Tooltip`, `ResponsiveContainer` (recharts), `getIntensityColorDark`
- Legend items simplified with a data array map

### `frontend/src/components/charts/RainfallLineChart.tsx`
- Replaced `any` types in `TooltipEntry` and `CustomTooltipProps` with proper interfaces
- `tickFormatter` prop typed as `(d: string) => string`

### `frontend/src/components/charts/TankLevelBarChart.tsx`
- Replaced `any` types in tooltip payload with typed `TooltipPayloadItem` interface
- `TankLevel` type used for color lookup

### `frontend/src/pages/Dashboard.tsx`
- Removed unused `DECISION_COLORS` import
- Replaced inline `colorMap` record with module-level `BADGE_CLASSES` constant
- Removed `eslint-disable react-hooks/incompatible-library` comment (now handled globally in `eslint.config.js`)
- `currentTank` null-coalescing cleaned up

### `frontend/src/pages/IrrigationPage.tsx`
- Removed unused `DECISION_COLORS` import
- `DECISION_BADGE` map defined at module level instead of inline
- Removed `eslint-disable` comment
- `exportToCSV` cast to `Record<string, unknown>[]` (was `Record<string, string | number>[]`)

### `frontend/src/pages/ModelComparisonPage.tsx`
- Removed unused `ModelMetricCard` and `formatMetric` imports
- Extracted `dedupeMetrics`, `getBestByRmse`, `getConfidence` as pure module-level helpers
- `metricsMap` dependency array now correct (no stale closure warning)
- `VALID_MODELS` and `TABS` lifted to module level
- `bestValFor` helper inlined into columns memo — resolves `metricsMap` stale dep warning
- Removed `eslint-disable` comment

### `frontend/src/pages/RainfallPage.tsx`
- Removed unused `formatMetric` import
- `any` types in `TooltipEntry` replaced with proper interface
- Metric columns for `rmse`/`mae` and `r2`/`nse` generated with array maps (DRY)
- `days` computation simplified
- Removed `eslint-disable` comment

### `frontend/eslint.config.js`
- Added global `react-hooks/incompatible-library: warn` rule to suppress TanStack Table
  false-positive project-wide, eliminating per-file `eslint-disable` comments

## Files NOT Changed (correct as-is)
- All API files (`rainfallApi.ts`, `tankApi.ts`, `irrigationApi.ts`)
- `types/index.ts`
- `store/useAppStore.ts`
- All other chart components (`MetricsBarChart`, `ModelComparisonRadar`, `TankLevelBarChart`)
- Card components (`StatCard`, `AlertCard`, `CropStatusCard`, `ModelMetricCard`)
- Layout components (`Layout`, `Sidebar`, `Topbar`)
- Shared components (`DateRangePicker`, `ErrorBoundary`, `LoadingSpinner`, `ModelSelector`)
- `App.tsx`, `main.tsx`, `index.css`
- All config files (`vite.config.ts`, `tailwind.config.ts`, `tsconfig*.json`, `postcss.config.js`)

## Files to Delete (dead code)
- `frontend/src/mocks/` — entire directory (mock JSONs never imported; API is always called)
- `scratch/` — development scripts, not part of the application
- `update_rainfall_metrics.py`, `train_standalone.py` — one-off scripts, not runtime code
